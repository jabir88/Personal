// function funOne(x, y) {
//   this.a = x;
//   this.b = y;
//   this.sum = function() {
//     return this.a + this.b;
//   };
// }
// let ongg = new funOne(21, 30);
// console.log(ongg.toString());

// let a = [20, "lAAa", "jabir"];

// let a = {
//   num: 20,
//   name: "Jabir",
//   comapany: "Oxilab",

// };
// let po = a[1].toLowerCase();
// console.log(po);
var collection_list = "";
var collection_right = "";
var collection_right_data = "";
var Sec_tab_lists = "";
let po = [];

(function poll() {
  $.ajax({
    url: "http://demo2406006.mockable.io/GetCollections",
    type: "GET",
    success: function(data) {
        console.log(data);
$.each(data, function(key, value) {
  // id="collection-1-tab"
  // data-toggle="pill"
  // href="#collection-1"
  // role="tab"
  // aria-controls="collection-1"
  // aria-selected="false"
  //wait
  // value.map(p => {

  // });
  value.forEach(element => {
    collection_list ="";
    collection_list +=
      '<a  class="nav-link left-list"  data-toggle="pill" id="collection-par' +
      element.ID +
      '" href="#collection' +
      element.ID +
      '"> ';
    collection_list += element.CollectionName;
    collection_list += "</a>";
    //  <div class="tab-pane fade  active show" id="collection796d79c3-9f16-47d8-a1f5-9fe2fa3fd3a5">
    //
    //         </div>
    collection_right +=
      '<div class="tab-pane fade  right-list" data-toggle="pill" id="collection' +
      element.ID +
      '" > ';

    collection_right +=
      ' <ul class="nav nav-tabs sec_tab" id="myTab" role="tablist"> <li class="nav-item">';
    collection_right +=
      '<a  class="nav-link active" data-toggle="tab" id="right-data-' +
      element.ID +
      '" href="#right-data-links' +
      element.ID +
      '"> ';
    collection_right += "List Data";
    collection_right += "</a></li>";
    collection_right += '  <li class="nav-item">';
    collection_right +=
      '<a  class="nav-link" data-toggle="tab" id="right-result-' +
      element.ID +
      '" href="#right-data-result' +
      element.ID +
      '"> ';
    collection_right += "Result";
    collection_right += "</a></li> </ul>";
    collection_right +=
      '<div      class="tab-pane fade show active"      id="right-data-links' +
      element.ID +
      '" role="tabpanel">';
    element.CollectionItems.forEach(inner => {
      collection_right += '<li class="list-group-item">';

      collection_right += inner.Name;

      collection_right += "</li>";
    });
    collection_right += "</div>";
    collection_right +=
      '<div      class="tab-pane fade "      id="right-data-result' +
      element.ID +
      '" role="tabpanel">';
  //   element.CollectionItems.forEach(inner => {
  //     collection_right += '<li class="list-group-item">';

    

  //     collection_right += "</li>";
  //   });
    collection_right += "</div>";
    // collection_right += ;
    // element.CollectionItems.forEach(inner => {
    //   collection_right_data += '<li class="list-group-item">';

    //   collection_right_data += inner.Name;

    //   collection_right_data += "</li>";
    // });

    collection_right += "</div>";
    $(".collection_list").append(collection_list);
    $(".collection_right").append(collection_right);

    $(".right_side_data").append(collection_right_data);
    collection_list = "";
     collection_right = "";
 collection_right_data = "";
    
  });
});


    },
    dataType: "json",
    complete: setTimeout(function() {poll()}, 5000),
    timeout: 2000
  })
})();

// console.log(po);

$(document).ready(function() {
  setTimeout(function() {
    $(".collection_list a:first").addClass("active show");
    $(".collection_right .right-list")
      .first()
      .addClass("active show");
  }, 1000);
});
